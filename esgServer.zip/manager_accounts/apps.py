from django.apps import AppConfig


class ManagerAccountsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "manager_accounts"
